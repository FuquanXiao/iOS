//
//  AViewController.h
//  WQAutoScrollLabel
//
//  Created by xfq on 2018/5/19.
//  Copyright © 2018年 xfq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AViewController : UIViewController

@end
