//
//  WQAutoScrollView.m
//  WQAutoScrollLabel
//
//  Created by xfq on 2018/5/19.
//  Copyright © 2018年 xfq. All rights reserved.
//

#import "WQAutoScrollView.h"

typedef void(^block)(UILabel *label);

static void each_Object(NSMutableArray *arrays,block labelBlock){
    for (UILabel *label in arrays) {
        labelBlock(label);
    }
}

@interface WQAutoScrollView()<UIScrollViewDelegate>
{
     CGFloat x;
}

@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,strong) NSMutableArray *lablSets;









/**
  Displaying lines  array  正在展示的label 数组；
  */
@property (nonatomic,strong) NSArray *currentLables;



@end
@implementation WQAutoScrollView


- (instancetype) initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initConfig];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        [self initConfig];
    }
    return self;
}

- (void)initConfig{
    // 创建label数组
    NSMutableSet * labelSet = [[NSMutableSet alloc] init];
    
    for (NSInteger i = 0; i < 2; i++) {
        UILabel * label = [UILabel new];
        label.backgroundColor = [UIColor clearColor];
        label.autoresizingMask = self.autoresizingMask;
        label.frame = CGRectMake(0, 0, 50, 50);
        [self.scrollView addSubview:label];
        [labelSet addObject:label];
    }
    self.lablSets = [labelSet.allObjects copy];
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.scrollEnabled = NO;
}


- (void)setText:(NSString *)scrollText{
    each_Object(self.lablSets, ^(UILabel *label) {
        label.text = scrollText;
    });
    [self refreshLabel];
}

- (UILabel *)scrollLable{
    return self.lablSets.firstObject;
}

- (NSString *)text{
    return self.scrollLable.text;
}

- (void)refreshLabel{
    __block CGFloat offset = 0;
    
    each_Object(self.lablSets, ^(UILabel *label) {
        [label sizeToFit];
        
        NSDictionary *attDict = @{NSFontAttributeName:[UIFont systemFontOfSize:21]};
        NSMutableAttributedString *attribute = [[NSMutableAttributedString alloc] initWithString:label.text attributes:attDict];
        
        CGSize size = [self.text boundingRectWithSize:self.bounds.size options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:attDict context:nil].size;
        
        CGSize heightSize = [self.text boundingRectWithSize:CGSizeMake(size.width, self.bounds.size.height) options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin attributes:attDict context:nil].size;
    
        
        label.frame = CGRectMake(offset, 0, size.width, heightSize.height);
        if (size.width>self.bounds.size.width) {
            offset = size.width + 100  + offset;
            
            
        }
        else{
            offset = self.bounds.size.width + 100  + offset;
            
        }
        
        
        
    });
    
    
    self.scrollView.contentSize = CGSizeMake(offset, self.scrollView.bounds.size.height);
    [self scroll];
   
}


- (void)startScroll{
    
}

- (void)stopScroll{
    
}


- (void)scroll{

    [UIView animateWithDuration:8 delay:0.01 options:UIViewAnimationOptionRepeat | UIViewAnimationOptionCurveLinear | UIViewAnimationOptionCurveEaseOut animations:^{

            self.scrollView.contentOffset = CGPointMake(self.scrollView.contentSize.width/2.0, 0);



    } completion:^(BOOL finished) {

        // 完成后循调用
        if (finished) {
            [self scroll];
        }
    }];
}

- (UIScrollView *)scrollView{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
        _scrollView.backgroundColor = [UIColor clearColor];
        [self addSubview:_scrollView];
        CAGradientLayer *_gradLayer = [CAGradientLayer layer];
        NSArray *colors = [NSArray arrayWithObjects:
                           (id)[[UIColor colorWithWhite:0 alpha:1] CGColor],
                           (id)[[UIColor colorWithWhite:0 alpha:0.95] CGColor],
                           (id)[[UIColor colorWithWhite:0 alpha:0.90] CGColor],
                           (id)[[UIColor colorWithWhite:0 alpha:0.85] CGColor],
                           (id)[[UIColor colorWithWhite:0 alpha:0.0] CGColor],
                           nil];
        [_gradLayer setColors:colors];
        //渐变起止点，point表示向量 (I.e. [0,0] is the bottom-left
//        * corner of the layer, [1,1] is the top-right corner.)
        [_gradLayer setStartPoint:CGPointMake(1.0f, 0.0f)];
        [_gradLayer setEndPoint:CGPointMake(0.0f, 0.0f)];
        
        [_gradLayer setFrame:self.bounds];
        
        [self.layer setMask:_gradLayer];

    }
    return _scrollView;
}

@end
